-- phpMyAdmin SQL Dump
-- version 2.11.0
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Jeu 14 Décembre 2023 à 17:22
-- Version du serveur: 4.1.22
-- Version de PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de données: `boutique`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `login` varchar(40) NOT NULL default '',
  `mot2passe` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `admin`
--

INSERT INTO `admin` (`login`, `mot2passe`) VALUES
('makhlouf.eya2022@gmail.com', '0000');

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `idArticle` int(10) NOT NULL auto_increment,
  `libelle` varchar(20) NOT NULL default '',
  `matiere` varchar(20) NOT NULL default '',
  `prix` float NOT NULL default '0',
  `img` text NOT NULL,
  PRIMARY KEY  (`idArticle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Contenu de la table `article`
--

INSERT INTO `article` (`idArticle`, `libelle`, `matiere`, `prix`, `img`) VALUES
(2, 'collier', 'argent', 250, 'new_product11.png'),
(3, 'collier 2', 'or', 2500, 'new_product22.png'),
(4, 'aaaaa', 'sss', 1200, 'new_product3.png'),
(5, 'collier 3', 'diamant', 1233, 'new_product11.png'),
(6, 'collier 3', 'diamant', 1233, 'popular22.png'),
(7, 'mmmmm', 'yyyyy', 12, 'new_product11.png'),
(8, 'mmmmm', 'yyyyy', 12, 'new_product11.png');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `idClient` int(10) NOT NULL auto_increment,
  `ncin` varchar(20) NOT NULL default '',
  `nom` varchar(20) NOT NULL default '',
  `prenom` varchar(20) NOT NULL default '',
  `numTel` varchar(20) NOT NULL default '',
  `adresse` varchar(20) NOT NULL default '',
  `email` varchar(40) NOT NULL default '',
  `password` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`idClient`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`idClient`, `ncin`, `nom`, `prenom`, `numTel`, `adresse`, `email`, `password`) VALUES
(5, '7', 'aaaa', 'bbbb', '9265445', 'rrrr', 'eyamakhlouf2@gmail.com', '0000'),
(6, '789', 'aaaa', 'cccc', '9265445', 'uuuuuu', 'yassine.makhlouf.yfm@outlook.fr', '0000'),
(7, '12345678', 'fatma', 'sassi', '12312331', 'rrrrrrrrr', 'fatmasassi@gmail.com', '0000'),
(8, '12345678', 'fatma', 'sassi', '12312331', 'rrrrrrrrr', 'fatmaaasassi@gmail.com', ''),
(9, '89', 'ssss', 'dddd', '123123', 'wwww', 'jjjknn@gmail.com', '1111');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE IF NOT EXISTS `commande` (
  `idCommande` int(10) NOT NULL auto_increment,
  `idClient` int(10) NOT NULL default '0',
  `idArticle` int(10) NOT NULL default '0',
  `quantite` float NOT NULL default '0',
  `dateCmd` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`idCommande`),
  KEY `idClient` (`idClient`),
  KEY `idArticle` (`idArticle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Contenu de la table `commande`
--

INSERT INTO `commande` (`idCommande`, `idClient`, `idArticle`, `quantite`, `dateCmd`) VALUES
(1, 6, 4, 1, '0000-00-00'),
(2, 5, 3, 230, '0000-00-00'),
(3, 6, 3, 2500, '0000-00-00'),
(4, 6, 3, 2500, '0000-00-00'),
(5, 6, 3, 2500, '0000-00-00'),
(6, 6, 5, 1233, '0000-00-00'),
(7, 6, 6, 1233, '0000-00-00'),
(8, 6, 3, 2500, '2023-12-10'),
(9, 6, 5, 1233, '2023-12-10'),
(10, 6, 6, 1233, '2023-12-10'),
(11, 5, 3, 4, '2023-12-21'),
(12, 6, 3, 2500, '2023-12-12'),
(13, 6, 3, 4, '2023-12-12'),
(14, 6, 4, 1, '2023-12-12'),
(15, 6, 3, 1, '2023-12-12'),
(16, 6, 4, 1, '2023-12-12');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`idClient`) REFERENCES `client` (`idClient`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `commande_ibfk_2` FOREIGN KEY (`idArticle`) REFERENCES `article` (`idArticle`) ON DELETE CASCADE ON UPDATE CASCADE;
